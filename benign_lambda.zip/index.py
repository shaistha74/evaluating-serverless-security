def handler(event, context):
    print("Benign Lambda executed")
    print(event)
    return {"status": "success", "message": "Processed normally"}
