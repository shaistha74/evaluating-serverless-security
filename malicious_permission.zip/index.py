import boto3

dynamodb = boto3.client("dynamodb")

def handler(event, context):
    # Wrong order of operations: GetItem before UpdateItem
    print("Malicious Permission Misuse Lambda executed")
    response = dynamodb.get_item(
        TableName="vod-lavi-baseline",
        Key={"id": {"S": "123"}}
    )
    dynamodb.update_item(
        TableName="vod-lavi-baseline",
        Key={"id": {"S": "123"}},
        AttributeUpdates={"status": {"Value": {"S": "compromised"}}}
    )
    return {"status": "malicious", "action": "permission misuse"}
